/**
* ***************************************************************
* Licensed Materials - Property of IBM
* 
* (c) Copyright IBM Corporation. 2007/2009. All Rights Reserved.
* 
* The source code for this program is not published or otherwise
* divested of its trade secrets, irrespective of what has been
* deposited with the U.S. Copyright Office.
* *************************************************************** 
* 
*/

package com.ibm.rational.test.lt.models.wscore.datamodel.security.xmlsec;

import java.util.Properties;
import org.w3c.dom.Document;


public interface ICustomSecurityAlgorithm {
	
	/**
	 * The following methods can be used in both case:
	 * Execution in the workbench using the test suite editor and 'common' execution of the test.
	 */
	
	
	/**
	 * Called to process de Document that is sent over a transport.
	 * @param subject
	 */
	void process(Document subject) throws Exception;
	/**
	 * Called to un process a document that is received from a server.
	 * Un process can be for example the un cryption procedure to turn an crypted document into something readable.
	 * @param subject
	 */
	void unProcess(Document subject) throws Exception;
	
	/**
	 * Properties defined in the UI of the CustomSecurityAlgorithm.
	 * @param map
	 */
	void setProperties(Properties map);

	
	/**
	 * This object corresponds to the ITestExecutionService object.
	 * This applyes only for algorithm which needs to have a link with the execution of the test.
	 * If you plan to use this object you will need to deploy the jar containing the implementation into your performacne 
	 * test project and not directly into the jre, as a result this algorithm cannot be used in the workbench.
	 * 
	 * In case of a need of the previous xml document received from the execution you can obtain the value using:
	 * 	IDataArea area = ((ITestExecutionService)executionObject).findDataArea(IDataArea.VIRTUALUSER);
		String previousXML = (String) area.get("PREVIOUS_XML"); //$NON-NLS-1$
	 * 
	 */
	void setExecutionContext(Object executionObject);

	
	
}
